import random
from datetime import datetime, timedelta
from faker import Faker

fake = Faker()

def random_date(start, end):
    return start + timedelta(days=random.randint(0, (end - start).days))

def generate_students(num_records, counselor_ids):
    students = []
    current_year = datetime.now().year
    for student_id in range(1, num_records + 1):
        name = fake.name()
        grade = random.randint(1, 12)
        birth_year = current_year - (6 + grade - 1)
        birth = random_date(datetime(birth_year, 1, 1), datetime(birth_year, 12, 31))
        address = fake.address().replace('\n', ', ')
        counselor_id = random.choice(counselor_ids)
        students.append((student_id, name, birth, grade, address, counselor_id))
    return students

def generate_sql_insert_statements(table, columns, records):
    sql_statements = []
    for record in records:
        values = ", ".join([f"'{r}'" if isinstance(r, str) else f"TO_DATE('{r.strftime('%Y-%m-%d')}', 'YYYY-MM-DD')" if isinstance(r, datetime) else str(r) for r in record])
        sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({values});"
        sql_statements.append(sql)
    return sql_statements

def generate_counselors(num_records):
    degree_levels = ['BA', 'MA', 'Doctor']
    counselors = []
    for counselor_id in range(1, num_records + 1):
        counselor_name = fake.name()
        degree_level = random.choice(degree_levels)
        counselor_age = random.randint(25, 65)
        counselor_email = fake.email()
        counselors.append((counselor_id, counselor_name, degree_level, counselor_age, counselor_email))
    return counselors

def generate_meals(num_records):
    meal_names = ['Hamburger', 'Spaghetti', 'Pizza', 'Salad', 'Sushi', 'Tacos', 'Pasta', 'Steak', 'Soup', 'Sandwich']
    meals = []
    for meal_id in range(1, num_records + 1):
        meal_name = random.choice(meal_names)
        meal_type = random.choice(['Breakfast', 'Lunch', 'Dinner'])
        is_dairy = random.choice(['Yes', 'No'])
        meals.append((meal_id, meal_type, is_dairy, meal_name))
    return meals

def generate_transportations(num_records):
    transportations = []
    for transportation_id in range(1, num_records + 1):
        departure_time = random_date(datetime(2023, 1, 1), datetime(2023, 12, 31))
        in_time = random.choice(['YES', 'NO'])
        driver_name = fake.name()
        transportations.append((transportation_id, departure_time, driver_name, in_time))
    return transportations

def generate_arrive_records(num_records, transportation_ids, student_ids):
    arrive_records = []
    for _ in range(num_records):
        transportation_id = random.choice(transportation_ids)
        student_id = random.choice(student_ids)
        arrive_records.append((transportation_id, student_id))
    return arrive_records

def generate_eater_records(num_records, meal_ids, student_ids):
    eater_records = []
    for _ in range(num_records):
        meal_id = random.choice(meal_ids)
        student_id = random.choice(student_ids)
        eater_records.append((meal_id, student_id))
    return eater_records

num_records = 400

# Generate Counselors
counselors = generate_counselors(num_records)
counselor_ids = [c[0] for c in counselors]
insert_statements = generate_sql_insert_statements('Counselor', ['Counselor_id', 'Counselor_name', 'Degree_level', 'Counselor_Age', 'Counselor_email'], counselors)
with open('insert_counselors.sql', 'w') as file:
    file.write('\n'.join(insert_statements))

# Generate Students
students = generate_students(num_records, counselor_ids)
student_ids = [s[0] for s in students]
insert_statements = generate_sql_insert_statements('Student_', ['Student_id', 'Name', 'Birth', 'Grade', 'Adress', 'Counselor_id'], students)
with open('insert_students.sql', 'w') as file:
    file.write('\n'.join(insert_statements))

# Generate Meals
meals = generate_meals(num_records)
meal_ids = [m[0] for m in meals]
insert_statements = generate_sql_insert_statements('Meals', ['Meal_id', 'Type_meal', 'Is_Dairy', 'Meal_name'], meals)
with open('insert_meals.sql', 'w') as file:
    file.write('\n'.join(insert_statements))

# Generate Transportations
transportations = generate_transportations(num_records)
transportation_ids = [t[0] for t in transportations]
insert_statements = generate_sql_insert_statements('Transportation', ['Transportation_id', 'departure_time', 'Driver_name', 'In_time'], transportations)
with open('insert_transportations.sql', 'w') as file:
    file.write('\n'.join(insert_statements))

# Generate Arrive Records
arrive_records = generate_arrive_records(num_records, transportation_ids, student_ids)
insert_statements = generate_sql_insert_statements('Arrive', ['Transportation_id', 'Student_id'], arrive_records)
with open('insert_arrive.sql', 'w') as file:
    file.write('\n'.join(insert_statements))

# Generate Eater Records
eater_records = generate_eater_records(num_records, meal_ids, student_ids)
insert_statements = generate_sql_insert_statements('Eater', ['Meal_id', 'Student_id'], eater_records)
with open('insert_eater.sql', 'w') as file:
    file.write('\n'.join(insert_statements))
