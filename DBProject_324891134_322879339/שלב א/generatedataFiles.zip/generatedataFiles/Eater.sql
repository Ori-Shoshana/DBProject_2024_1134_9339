INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (44,27);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (327,195);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (155,279);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (186,91);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (94,244);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (370,114);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (161,372);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (51,153);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (49,231);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (134,225);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (256,300);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (368,346);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (246,138);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (218,145);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (112,332);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (343,93);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (138,75);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (257,390);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (90,52);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (27,79);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (337,303);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (110,77);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (275,355);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (176,351);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (8,310);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (114,377);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (46,126);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (141,117);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (184,205);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (385,379);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (368,199);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (229,114);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (309,287);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (320,283);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (248,279);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (45,106);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (256,146);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (233,11);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (95,258);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (176,116);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (301,189);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (8,117);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (268,235);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (237,159);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (248,84);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (119,388);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (44,357);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (397,347);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (312,41);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (283,371);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (34,247);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (135,333);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (166,27);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (11,356);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (286,270);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (233,169);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (298,274);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (196,169);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (359,90);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (92,86);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (144,212);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (84,334);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (221,89);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (72,199);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (268,331);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (143,4);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (345,380);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (161,224);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (56,217);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (143,36);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (12,188);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (215,146);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (248,236);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (382,254);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (241,316);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (345,130);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (72,279);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (274,280);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (167,189);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (6,235);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (247,176);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (392,388);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (359,162);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (330,161);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (354,205);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (334,183);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (308,87);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (330,119);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (152,279);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (199,273);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (204,34);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (199,97);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (357,17);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (93,196);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (199,256);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (362,282);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (260,336);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (40,24);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (38,261);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (58,168);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (89,142);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (145,43);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (259,89);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (155,179);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (202,323);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (125,312);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (223,377);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (185,313);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (176,227);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (190,59);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (50,20);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (194,71);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (193,317);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (110,82);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (335,359);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (280,68);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (296,28);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (251,335);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (188,287);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (242,86);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (219,234);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (197,315);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (330,377);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (382,275);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (215,178);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (299,265);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (126,56);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (77,100);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (199,190);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (332,354);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (113,360);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (383,12);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (65,229);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (17,366);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (254,165);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (253,61);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (158,344);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (286,155);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (255,3);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (309,10);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (281,129);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (93,118);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (213,76);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (58,374);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (122,352);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (99,322);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (208,43);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (214,363);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (81,235);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (2,360);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (374,372);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (350,155);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (121,5);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (54,200);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (73,30);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (131,312);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (64,365);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (181,371);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (225,108);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (87,138);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (180,154);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (16,39);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (106,180);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (337,220);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (83,351);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (113,105);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (252,208);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (69,283);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (57,63);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (145,217);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (94,115);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (114,168);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (156,180);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (372,348);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (343,202);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (310,312);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (177,222);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (274,223);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (45,25);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (291,228);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (121,201);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (335,24);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (57,185);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (309,337);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (204,320);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (154,260);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (53,3);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (245,195);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (24,327);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (56,55);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (199,338);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (163,209);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (13,109);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (25,194);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (100,95);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (334,95);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (197,14);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (90,1);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (35,23);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (70,363);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (314,273);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (284,244);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (120,311);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (27,252);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (228,223);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (156,386);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (302,142);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (66,236);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (315,198);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (317,147);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (336,357);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (232,271);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (259,213);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (178,228);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (72,91);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (343,128);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (272,77);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (245,306);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (265,277);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (399,243);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (331,86);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (251,350);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (274,356);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (6,319);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (294,113);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (245,117);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (41,189);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (210,43);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (244,248);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (190,285);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (201,165);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (379,297);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (204,124);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (13,380);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (157,156);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (44,26);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (281,299);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (117,331);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (258,323);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (312,240);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (4,322);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (244,26);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (151,369);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (292,203);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (179,348);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (139,181);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (103,151);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (259,126);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (49,112);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (290,268);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (239,395);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (381,88);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (386,336);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (369,177);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (381,279);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (330,388);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (138,65);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (278,108);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (142,88);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (1,334);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (123,275);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (199,243);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (144,264);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (155,29);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (237,113);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (184,30);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (216,19);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (87,75);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (260,26);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (197,338);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (97,136);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (283,232);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (315,159);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (285,34);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (359,8);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (114,204);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (240,206);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (13,151);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (376,295);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (181,370);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (177,279);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (271,46);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (368,291);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (110,365);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (117,158);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (170,209);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (51,203);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (238,228);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (23,63);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (338,240);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (98,342);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (183,280);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (368,199);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (323,334);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (257,113);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (94,184);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (80,237);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (2,232);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (259,348);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (81,115);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (60,130);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (256,173);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (195,90);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (383,24);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (292,234);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (81,171);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (305,262);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (50,391);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (299,326);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (133,121);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (143,241);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (385,300);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (377,116);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (386,210);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (384,42);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (311,398);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (19,171);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (79,154);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (246,245);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (60,291);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (259,176);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (385,351);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (384,82);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (186,7);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (359,263);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (218,212);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (59,368);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (229,282);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (50,23);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (41,247);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (345,187);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (249,71);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (394,368);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (389,38);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (222,56);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (180,359);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (327,58);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (149,159);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (338,32);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (356,319);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (199,23);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (153,235);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (237,38);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (289,335);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (182,68);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (136,265);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (229,161);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (160,176);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (117,305);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (232,204);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (237,399);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (154,375);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (393,34);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (31,238);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (8,298);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (141,63);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (328,378);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (33,292);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (381,38);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (333,272);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (217,283);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (333,211);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (283,238);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (29,228);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (337,264);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (199,110);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (15,301);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (124,15);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (89,141);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (187,74);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (180,277);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (163,78);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (283,335);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (298,73);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (182,310);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (136,96);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (309,251);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (312,199);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (222,191);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (243,377);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (165,223);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (237,115);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (348,203);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (285,275);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (321,24);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (298,192);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (111,106);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (171,217);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (55,278);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (193,103);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (256,249);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (190,197);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (230,21);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (61,284);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (274,394);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (195,137);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (258,300);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (23,392);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (310,104);
INSERT INTO `Eater` (`Meal_id`,`Student_id`)
VALUES (112,14);
