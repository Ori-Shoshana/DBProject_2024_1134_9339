INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (308,338);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (347,237);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (120,339);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (2,58);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (77,89);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (108,74);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (395,148);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (63,343);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (108,243);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (159,310);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (148,378);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (224,216);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (376,3);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (322,392);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (255,223);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (43,123);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (55,296);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (92,132);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (185,252);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (197,100);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (114,174);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (88,93);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (357,193);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (100,190);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (32,52);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (344,289);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (364,147);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (122,383);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (368,42);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (160,45);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (301,140);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (120,115);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (286,191);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (134,209);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (355,112);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (350,27);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (305,383);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (242,110);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (148,67);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (288,276);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (233,141);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (36,114);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (243,125);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (44,50);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (205,261);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (162,359);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (57,305);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (45,165);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (268,146);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (215,137);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (299,125);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (332,90);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (277,370);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (271,15);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (93,5);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (336,235);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (219,25);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (24,102);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (164,245);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (236,319);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (114,149);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (288,73);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (228,27);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (131,248);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (76,343);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (297,183);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (4,40);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (350,130);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (62,180);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (233,256);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (20,49);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (111,183);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (266,192);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (47,291);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (320,206);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (298,290);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (25,74);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (257,45);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (229,205);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (8,395);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (90,210);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (238,395);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (389,275);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (277,46);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (6,338);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (17,263);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (123,108);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (304,262);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (41,41);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (187,47);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (238,399);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (80,367);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (348,223);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (289,92);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (29,92);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (15,327);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (397,242);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (251,71);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (392,209);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (225,396);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (32,261);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (196,202);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (117,394);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (274,120);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (332,101);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (325,137);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (14,127);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (308,24);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (165,41);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (183,267);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (382,230);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (129,315);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (165,390);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (343,181);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (33,78);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (205,156);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (238,215);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (395,292);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (223,6);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (153,164);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (33,133);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (42,344);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (194,56);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (194,90);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (359,246);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (166,136);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (268,264);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (7,115);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (394,74);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (296,218);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (184,128);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (328,288);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (292,386);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (12,202);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (144,3);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (356,42);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (129,64);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (137,139);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (284,81);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (132,19);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (160,252);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (51,161);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (227,317);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (339,174);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (17,253);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (217,271);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (35,389);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (369,292);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (319,16);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (222,149);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (172,232);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (281,319);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (117,112);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (122,215);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (289,91);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (226,118);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (390,101);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (61,364);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (193,253);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (273,398);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (185,176);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (180,210);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (68,13);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (127,188);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (88,275);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (189,9);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (30,315);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (341,192);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (215,28);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (182,345);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (10,126);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (53,137);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (285,249);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (54,309);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (248,206);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (386,43);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (108,90);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (266,357);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (140,210);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (36,110);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (362,175);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (244,208);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (397,62);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (166,295);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (318,228);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (102,40);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (89,40);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (391,335);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (375,36);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (167,243);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (171,269);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (256,341);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (376,362);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (283,4);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (80,361);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (47,87);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (267,21);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (365,110);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (217,255);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (267,356);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (243,116);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (165,358);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (195,231);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (390,45);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (193,177);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (60,236);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (246,378);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (307,59);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (296,142);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (25,12);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (208,220);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (90,369);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (30,22);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (273,391);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (356,252);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (317,168);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (320,241);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (36,175);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (352,159);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (194,51);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (159,277);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (13,78);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (184,148);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (198,169);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (315,258);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (310,175);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (110,143);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (94,318);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (330,351);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (279,267);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (347,277);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (68,166);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (290,185);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (309,328);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (72,131);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (134,329);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (130,26);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (229,336);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (239,99);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (201,315);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (302,67);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (123,141);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (310,357);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (296,23);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (106,119);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (6,295);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (30,324);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (202,338);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (103,248);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (28,350);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (244,45);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (328,309);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (249,354);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (29,227);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (41,347);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (290,234);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (139,159);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (103,123);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (300,190);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (225,184);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (162,349);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (89,216);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (175,226);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (397,18);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (156,234);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (117,239);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (37,55);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (345,232);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (33,315);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (299,239);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (160,227);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (232,15);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (127,230);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (232,102);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (395,277);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (216,37);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (318,246);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (213,52);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (294,174);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (136,272);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (380,262);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (209,244);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (262,154);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (200,153);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (328,99);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (232,343);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (18,256);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (15,212);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (242,94);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (392,77);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (210,194);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (189,256);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (46,102);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (153,361);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (258,91);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (217,204);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (67,104);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (23,80);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (36,54);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (108,369);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (178,181);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (251,108);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (361,226);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (394,229);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (156,170);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (246,175);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (332,53);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (361,358);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (180,68);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (85,34);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (382,392);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (295,183);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (154,319);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (216,254);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (171,379);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (315,336);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (217,13);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (68,298);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (203,308);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (374,231);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (81,353);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (155,351);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (21,52);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (330,123);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (378,379);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (138,191);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (333,245);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (337,307);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (126,256);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (237,2);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (350,30);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (175,284);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (261,92);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (194,178);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (82,197);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (166,385);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (111,73);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (180,184);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (14,46);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (298,34);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (195,45);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (14,21);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (106,268);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (322,11);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (154,28);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (279,315);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (12,181);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (45,268);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (200,86);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (48,126);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (270,378);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (83,351);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (166,146);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (167,194);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (146,75);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (30,315);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (33,372);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (286,187);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (128,220);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (377,27);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (324,75);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (173,243);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (127,204);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (396,322);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (35,259);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (124,94);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (206,42);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (77,43);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (361,15);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (282,85);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (344,277);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (330,5);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (237,17);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (26,3);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (136,45);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (400,171);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (50,311);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (193,249);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (121,344);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (243,24);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (170,260);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (45,328);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (332,69);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (291,6);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (174,296);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (42,19);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (40,194);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (362,269);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (21,166);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (275,212);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (279,69);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (210,177);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (361,62);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (325,99);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (276,44);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (264,227);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (119,292);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (219,104);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (330,82);
INSERT INTO `Going` (`Student_id`,`Trip_maneger_id`)
VALUES (339,357);
